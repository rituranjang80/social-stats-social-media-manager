Social Stats — personal data export
-----------------------------
Subject: admin@demo.local
Generated: 2026-07-30T20:01:16.530628+00:00

Files in this archive:
  • profile.json
  • workspaces.json
  • consents.json
  • export_requests.json
  • deletion_requests.json
  • README.txt

Questions? privacy@socialstats.app
